var structNVAPI__D3D12__PSO__SET__SHADER__EXTENSION__SLOT__DESC__V1 =
[
    [ "registerSpace", "structNVAPI__D3D12__PSO__SET__SHADER__EXTENSION__SLOT__DESC__V1.html#ab7464d69f8f6f0e902f27baf06a6e324", null ],
    [ "uavSlot", "structNVAPI__D3D12__PSO__SET__SHADER__EXTENSION__SLOT__DESC__V1.html#afbb8e00ec5464a313c5ba58af56a835d", null ],
    [ "version", "structNVAPI__D3D12__PSO__SET__SHADER__EXTENSION__SLOT__DESC__V1.html#a39b220f109e37029fd9d88da29bef09c", null ]
];
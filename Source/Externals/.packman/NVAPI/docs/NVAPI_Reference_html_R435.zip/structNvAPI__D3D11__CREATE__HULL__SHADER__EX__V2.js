var structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#a495fdb3cfb1e4e0ac91f58e83d620d3e", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#ade8f5c9f62c8b3d84ccb04a3387f1ae7", null ],
    [ "UseSpecificShaderExt", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#a407f933fae953b1125deef68cf61dab5", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#a0a407866df48f8e217cd2d89b368d30c", null ],
    [ "version", "structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#adde82bc41569e81f5810e9fe4e4aef4c", null ]
];
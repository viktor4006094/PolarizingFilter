var structNV__LID__DOCK__PARAMS =
[
    [ "currentDockPolicy", "structNV__LID__DOCK__PARAMS.html#aea3edf8c50f734e715fea36b18c7f77c", null ],
    [ "currentDockState", "structNV__LID__DOCK__PARAMS.html#a3052cfbbd0d640e4aa8813067d9f842c", null ],
    [ "currentLidPolicy", "structNV__LID__DOCK__PARAMS.html#ae9a68a17cd80db8d5802da4eec5b9ca4", null ],
    [ "currentLidState", "structNV__LID__DOCK__PARAMS.html#ae0078cea5d22d646409d4975cbeced33", null ],
    [ "forcedDockMechanismPresent", "structNV__LID__DOCK__PARAMS.html#a7f239b363309a42202bad75c90e86ff7", null ],
    [ "forcedLidMechanismPresent", "structNV__LID__DOCK__PARAMS.html#acafb1b63026f3b6b34730d6ef720cdba", null ],
    [ "version", "structNV__LID__DOCK__PARAMS.html#a67d9d12538a2d3c087673b9e7986e736", null ]
];
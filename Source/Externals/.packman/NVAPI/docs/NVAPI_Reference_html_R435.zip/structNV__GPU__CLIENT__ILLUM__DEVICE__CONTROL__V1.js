var structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__V1 =
[
    [ "rsvd", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__V1.html#ab612853d886ccbca46b148af0303eeda", null ],
    [ "syncData", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__V1.html#ac8aceeae23c1b3b095b2472e57cec500", null ],
    [ "type", "structNV__GPU__CLIENT__ILLUM__DEVICE__CONTROL__V1.html#a1658d443934ccbfc3c7a7ad43d386489", null ]
];
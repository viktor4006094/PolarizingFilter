var structNV__GPU__ECC__ERROR__INFO =
[
    [ "aggregate", "structNV__GPU__ECC__ERROR__INFO.html#acc73781bd1570e340ff4a5b0aa2eff60", null ],
    [ "current", "structNV__GPU__ECC__ERROR__INFO.html#ad7a54d3b7025e2f01469389663adbc6e", null ],
    [ "doubleBitErrors", "structNV__GPU__ECC__ERROR__INFO.html#a4fff095cb14428dd04cb4feab250db8e", null ],
    [ "singleBitErrors", "structNV__GPU__ECC__ERROR__INFO.html#a6da06dde433aa1d8b8d63f7b5d86d2a1", null ],
    [ "version", "structNV__GPU__ECC__ERROR__INFO.html#aba5f279d433761d2c6ba1b15e23626eb", null ]
];
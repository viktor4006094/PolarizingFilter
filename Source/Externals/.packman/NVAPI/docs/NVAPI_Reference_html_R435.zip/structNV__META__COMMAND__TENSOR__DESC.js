var structNV__META__COMMAND__TENSOR__DESC =
[
    [ "DataType", "structNV__META__COMMAND__TENSOR__DESC.html#a073b849f28c769e4d2c6bf8b7b21f549", null ],
    [ "DimensionCount", "structNV__META__COMMAND__TENSOR__DESC.html#a86e8c3379339b60be2a71747cd1f60bc", null ],
    [ "Flags", "structNV__META__COMMAND__TENSOR__DESC.html#a28ae01fdbc6c470bbc13fe62a2efa06e", null ],
    [ "Layout", "structNV__META__COMMAND__TENSOR__DESC.html#a8ba2ee421e7eb3cb1a81a14ac01eb0d7", null ],
    [ "Size", "structNV__META__COMMAND__TENSOR__DESC.html#a5b83c8e5a12c9cd1612a715a2ab25ba5", null ],
    [ "Stride", "structNV__META__COMMAND__TENSOR__DESC.html#ae6faa7954c2dee0c4043a56c24bce459", null ]
];
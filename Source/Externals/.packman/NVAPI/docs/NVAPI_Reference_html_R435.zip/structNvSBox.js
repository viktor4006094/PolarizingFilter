var structNvSBox =
[
    [ "sHeight", "structNvSBox.html#a11be54fe15283b27acd32dc57b85b4e1", null ],
    [ "sWidth", "structNvSBox.html#a022573b7f4d7cf3319a6dfe3a7a1d190", null ],
    [ "sX", "structNvSBox.html#aa01c1783309777bb0fc1fab4b49ceae8", null ],
    [ "sY", "structNvSBox.html#a9eb1cb7cea5489711fd63be8094b4e3a", null ]
];
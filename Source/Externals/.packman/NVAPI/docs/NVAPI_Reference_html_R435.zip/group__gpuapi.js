var group__gpuapi =
[
    [ "GPU General Control Interface", "group__gpu.html", "group__gpu" ],
    [ "GPU Performance Interface", "group__gpuPerf.html", "group__gpuPerf" ],
    [ "GPU Thermal Control Interface", "group__gputhermal.html", "group__gputhermal" ],
    [ "GPU Performance State Interface", "group__gpupstate.html", "group__gpupstate" ],
    [ "GPU Clock Control Interface", "group__gpuclock.html", "group__gpuclock" ],
    [ "GPU Cooler Interface", "group__gpucooler.html", "group__gpucooler" ],
    [ "GPU ECC Interface", "group__gpuecc.html", "group__gpuecc" ]
];
var group__nvapifunctions =
[
    [ "NvAPI_GetErrorMessage", "group__nvapifunctions.html#ga855150ebfbe69139b26a9e6dcd4da077", null ],
    [ "NvAPI_GetInterfaceVersionString", "group__nvapifunctions.html#ga5b083676716a90156b9b634c69c7eea2", null ],
    [ "NvAPI_Initialize", "group__nvapifunctions.html#ga773e227cecd41f303965a89446baa5e3", null ],
    [ "NvAPI_Unload", "group__nvapifunctions.html#gaac13a47b132d2aa6e2ca01731f9244e3", null ]
];
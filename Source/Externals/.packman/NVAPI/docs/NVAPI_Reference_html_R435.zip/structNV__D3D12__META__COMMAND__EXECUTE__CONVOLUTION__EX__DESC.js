var structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC =
[
    [ "Alpha1Resource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a3dd9f6803165e285a0818683f045a93e", null ],
    [ "Alpha2Resource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#aa3c46122a8853192ae29e9f530a717c0", null ],
    [ "BiasResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#aff3a12e69d307befc66d705127aa33f4", null ],
    [ "FilterResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#ab13b2e113d5ad7450a324aeaa65303fb", null ],
    [ "InputResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a278bffbe8ec727677199bb4022948709", null ],
    [ "OutputResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#afd11c6f5d017cf89cbbb00f813dc58db", null ],
    [ "PersistentResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#aeb61e37e195964e88d188f6ce0048ac9", null ],
    [ "SkipConnectionResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a1a8ac9cb7364d8d821f15c146319f140", null ],
    [ "TemporaryResource", "structNV__D3D12__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a719d544297796c3c0b6cc050a9fe864c", null ]
];
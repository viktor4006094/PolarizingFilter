var structNV__META__COMMAND__ACTIVATION__DESC =
[
    [ "Function", "structNV__META__COMMAND__ACTIVATION__DESC.html#ac3cd593887fa102de68afce25e477bc4", null ],
    [ "Params", "structNV__META__COMMAND__ACTIVATION__DESC.html#a9da15ae40d6320bb26be805ca4207fb6", null ]
];
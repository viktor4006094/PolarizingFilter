var structNV__GPU__PERF__PSTATES20__PARAM__DELTA =
[
    [ "max", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#ab3ac87a374aedb15cc976e8eb92df56f", null ],
    [ "min", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#a7b86d610c090772cc858bac5e7ebe653", null ],
    [ "value", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#a07653ba935631aa1232dcf741818b78e", null ],
    [ "valueRange", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#aa262f6d9cc1158a17d4b18f0d50237ea", null ]
];
var concepts =
[
    [ "NvAPI Handles", "handles.html", null ],
    [ "Structure Versions Must be Initialized", "structureversions.html", null ],
    [ "Use a Static Link with Applications", "staticlink.html", null ],
    [ "NVAPI Security", "nvapisecurity.html", null ]
];
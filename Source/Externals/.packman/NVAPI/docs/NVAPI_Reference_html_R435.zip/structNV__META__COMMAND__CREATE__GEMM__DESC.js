var structNV__META__COMMAND__CREATE__GEMM__DESC =
[
    [ "Activation", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a990f4e53aa1780d0d33f0dbcd1ea894f", null ],
    [ "Alpha", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a999ca72245c345604adb3f910e15a98f", null ],
    [ "Beta", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a86dbd8da14335899c6028450cbc81cda", null ],
    [ "DescA", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a02317f14f7e1f07988b41e127c1f758e", null ],
    [ "DescB", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a0b2dad1cdb6fcb303980e961122a9efd", null ],
    [ "DescC", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a2330414fe25423e24a20b5fc025ae6ca", null ],
    [ "DescOut", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a6561b844f6e55429e9592f484bd5f9d7", null ],
    [ "Precision", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a05fb6b9c0b82e34677949b410bf45154", null ],
    [ "TransA", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#ac25f6647672bee14539b4bb6de4e98e8", null ],
    [ "TransB", "structNV__META__COMMAND__CREATE__GEMM__DESC.html#a3b338ec3b1b5770680ee9f34d1f3d406", null ]
];
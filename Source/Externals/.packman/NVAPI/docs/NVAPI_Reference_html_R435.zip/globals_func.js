var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "n", "globals_func_n.html", null ]
];
var structNV__D3D11__META__COMMAND__RESOURCE =
[
    [ "Offset", "structNV__D3D11__META__COMMAND__RESOURCE.html#adcbdbab6684b35940f4007f2b10cbcad", null ],
    [ "ResourceHandle", "structNV__D3D11__META__COMMAND__RESOURCE.html#aa6f87da31c4fd6dc76c43c4a1f2c20ed", null ],
    [ "unused", "structNV__D3D11__META__COMMAND__RESOURCE.html#aae59c34460dba28e3688c07732b69e90", null ]
];
var structNV__META__COMMAND__PADDING__DESC =
[
    [ "ConstantPadVal", "structNV__META__COMMAND__PADDING__DESC.html#a2f5192aec8858df30657591d9e4dcd05", null ],
    [ "Mode", "structNV__META__COMMAND__PADDING__DESC.html#a8820ebd9ebd2bc7115ce389ce3c9965d", null ]
];
var structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V1 =
[
    [ "NumCustomSemantics", "structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V1.html#ad4a8164e46c2dd32cd37bb0b83313704", null ],
    [ "pCustomSemantics", "structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V1.html#a142a3a875270ff1b91b9a72279395939", null ],
    [ "version", "structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V1.html#a4aff85de30f7c9ce002bdf6899fbf640", null ]
];
var structNV__GPU__GET__HDCP__SUPPORT__STATUS =
[
    [ "hdcpFuseState", "structNV__GPU__GET__HDCP__SUPPORT__STATUS.html#ac58efbd30090e19a98bdab67e45482fe", null ],
    [ "hdcpKeySource", "structNV__GPU__GET__HDCP__SUPPORT__STATUS.html#af87135e4bbb95b47e7d0e6c3a2b0735d", null ],
    [ "hdcpKeySourceState", "structNV__GPU__GET__HDCP__SUPPORT__STATUS.html#a89ae1295efa44cecf1e7772de33fdddd", null ],
    [ "version", "structNV__GPU__GET__HDCP__SUPPORT__STATUS.html#a49597b038ff29c1e3d4b787411eda831", null ]
];
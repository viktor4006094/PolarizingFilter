var group__nvapihandles =
[
    [ "NV_BIT", "group__nvapihandles.html#gafc0ef7a37b27110bd28bc18de1bc2f29", null ],
    [ "NVAPI_DEFAULT_HANDLE", "group__nvapihandles.html#ga1b5f0e9e30385d3400957ab7693b740d", null ],
    [ "StereoHandle", "group__nvapihandles.html#ga1a88531978f553ee713f7ce29f2cb980", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga40e5767827717a82ccce272346b5098b", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga09a31b0b5d7cd90e884f33cdc3640a57", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga7dac58cdc332aefdcc6535060e060bd4", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga31e79d4b14c37774a33be9a94f63d5b8", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga87bf1f95f81e73e6baf19de2b811bfee", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#gaf24283cdd0f1c2c6b9cd02677d4bc950", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga9aaa7fcf6d037e828a06f0179ec85022", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga61eb6758522a825eafb655e78649f607", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga6a0e3476edf859b4ee91f77d0ade5164", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#gae94f0896fad11da9ef0d96942d0ecb74", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga245fa3062d764ca231d80c73a8ece64b", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga269df24e44e9ccd5dd184f97a55b397c", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#gac949884024cd78306cd6c3f0232f15ec", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#gaefa5d09e6b41b6cace5c1b1e491ebe21", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga6f07098cfe48c834859e31bd259e9a64", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga32ff445ab1e945c0d1494d51c54adcd8", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga66f43d3b914299f0bf63275f4b2336ae", null ],
    [ "NV_DECLARE_HANDLE", "group__nvapihandles.html#ga0e16c7811f9561a6a97cbb9c4aebf94e", null ]
];
var structNV__GPU__PERF__PSTATES__INFO__V2 =
[
    [ "clocks", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a8e3b39e1f0582cdde5625fd7b7206eb7", null ],
    [ "domainId", "structNV__GPU__PERF__PSTATES__INFO__V2.html#ab30ac30e900d54bffc17c94cea6e55f9", null ],
    [ "domainId", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a5dc380a3c37d96a48801e7bc90361c74", null ],
    [ "flags", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a303c5672d531eb3f83758a8b6b819015", null ],
    [ "freq", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a8923d6b11281c8bb133ecc58eeecaf14", null ],
    [ "mvolt", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a35de4d9868243584c8bccf39d4aab856", null ],
    [ "numClocks", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a3207a2e811e43b2e31a2e25289202957", null ],
    [ "numPstates", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a802002f70b469d8f9bc0e9d191a9e3b0", null ],
    [ "numVoltages", "structNV__GPU__PERF__PSTATES__INFO__V2.html#aede37db06c865a48bd4300c684d46a94", null ],
    [ "pstateId", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a86e817d27b269ef7da03abe950b872f2", null ],
    [ "pstates", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a7b1cb2a4e82ac68cae290929d2a3f9c5", null ],
    [ "version", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a357a01ab01dc89f5ea1bb3c2ec593199", null ],
    [ "voltages", "structNV__GPU__PERF__PSTATES__INFO__V2.html#a01f89d5172f06465055aba122db2571d", null ]
];
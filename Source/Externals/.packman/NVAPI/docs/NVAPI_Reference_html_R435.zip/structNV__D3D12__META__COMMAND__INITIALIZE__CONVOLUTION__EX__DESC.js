var structNV__D3D12__META__COMMAND__INITIALIZE__CONVOLUTION__EX__DESC =
[
    [ "PersistentResource", "structNV__D3D12__META__COMMAND__INITIALIZE__CONVOLUTION__EX__DESC.html#a6c5bfb5ab6ddc0390dccc892ec2f1251", null ]
];
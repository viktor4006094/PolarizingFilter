var structNV__DISPLAY__PATH =
[
    [ "bFocusDisplay", "structNV__DISPLAY__PATH.html#ac94c11939fc55d30dbbab9dabfd10f5d", null ],
    [ "bForceModeSet", "structNV__DISPLAY__PATH.html#a553f4394c9930936fba2ef31b324ef22", null ],
    [ "bGDIPrimary", "structNV__DISPLAY__PATH.html#a3758f5743b74faa484f7a236ae97ed73", null ],
    [ "bPrimary", "structNV__DISPLAY__PATH.html#a1af3cc56191a291806454afa9f7cbecb", null ],
    [ "colorFormat", "structNV__DISPLAY__PATH.html#adec963165343dbfd0b04a807e19f4d8d", null ],
    [ "connector", "structNV__DISPLAY__PATH.html#a0666f60787c897d735ae685430f0273e", null ],
    [ "depth", "structNV__DISPLAY__PATH.html#a3a401cd0e5abdceb1469cd810a7c411f", null ],
    [ "deviceMask", "structNV__DISPLAY__PATH.html#a132a853d0f45d50a7756338189e40c1f", null ],
    [ "gpuId", "structNV__DISPLAY__PATH.html#ad2ffba6a0981d5aa53bf1dae122c8e52", null ],
    [ "height", "structNV__DISPLAY__PATH.html#aef74a97e24ca8dad0a9b805fc0d8d766", null ],
    [ "interlaced", "structNV__DISPLAY__PATH.html#ac03d05699c2ad6c1ebe12de3714f006f", null ],
    [ "posx", "structNV__DISPLAY__PATH.html#a057bf2e66803047bb1889ab80bd6d909", null ],
    [ "posy", "structNV__DISPLAY__PATH.html#a3e1e222c13e5caa26d6ad0abcc337980", null ],
    [ "refreshRate", "structNV__DISPLAY__PATH.html#ab826e20e3ad864b7d9f9957287d9aca4", null ],
    [ "rotation", "structNV__DISPLAY__PATH.html#a215d2ac47a38a4a2d036a5caae9482b4", null ],
    [ "scaling", "structNV__DISPLAY__PATH.html#ab67aa7110b36c4484278a25073cda404", null ],
    [ "sourceId", "structNV__DISPLAY__PATH.html#a2f2a3255bbdd5a04118be0e6e30aa499", null ],
    [ "tvFormat", "structNV__DISPLAY__PATH.html#a615f4785b040e546f9986cc571d25d75", null ],
    [ "width", "structNV__DISPLAY__PATH.html#a1d1b7cb2e2e1aad18a8bb658f538877c", null ]
];
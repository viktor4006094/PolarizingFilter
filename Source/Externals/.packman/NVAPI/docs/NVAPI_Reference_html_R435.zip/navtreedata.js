var NAVTREE =
[
  [ "NVAPI Reference Documentation (Developer)", "index.html", [
    [ "NVIDIA NVAPI", "index.html", "index" ],
    [ "Legal Notice", "legal.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", "globals_enum" ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"NvApiDriverSettings_8h.html",
"NvApiDriverSettings_8h.html#a41696a45630f04d7e3e07b6296e04d1a",
"NvApiDriverSettings_8h.html#a89a336a3523bfefa2b3e59b330c8634ba5c1741bf6150295273c4762c5d884014",
"NvApiDriverSettings_8h.html#ab8f307c632ffd31ce8a55aa7e772e3b6ac0a4da57ca8153aef45927f3bc65275c",
"functions_vars_h.html",
"group__dispcontrol.html#gac8dac376cc5d1217fa1a5e8941cb1c2b",
"group__drsapi.html#ga0fdb525b01f114847f0d94fa9827994b",
"group__dx.html#ga8e4f1d1193de0b7326edc50ec4f024c6",
"group__dx.html#gga5f2937f412681437a5c8cfd64c666916a2f22c9d4ab7dc75b2e8312ffd4d491c1",
"group__gpu.html#gab0b142ecc19a54dc32c773f1f96f6f5f",
"group__gpu.html#ggad2c9cba35950627aa2fbde09dbd4d541acfe7bd712e8579dfa19004f425342afe",
"group__gsyncapi.html#ga6df26d3d01f6b14902bb3c8ce727876f",
"group__nvapifunctions.html#ga773e227cecd41f303965a89446baa5e3",
"group__nvapistatus.html#gga12534f3b520256799842c0172e9afdf7ac0a1f80201098a9507fc67b933c2b7b4",
"group__stereoapi.html#ga2161f3cab9e2b0f096d54fa43755826e",
"group__vidio.html#ga0fd9630eb873548188ea239a8411682f",
"group__vidio.html#ggae1f8ba4a323ebe9a5f20e6b7a37ae475a46749c45f96d095772c4214eecafcd21",
"nvHLSLExtns_8h.html#a65000924ce8145ade45fb42f10f86154",
"nvapi_8h.html#a178ec568987d5e1984c11938c84b8efcae5ab8e63efb55f9515b59f54e7d3f226",
"nvapi_8h.html#a3b3bc0188f97c3afc3a82504ac2c8975",
"nvapi_8h.html#a7b221e86bf6b118a69087401f5705644",
"nvapi_8h.html#aab120b19aad43b5d48e9923fb814d0c2a02fa3032fa36a8d5c41c372ab1aee741",
"nvapi_8h.html#ade7dd7a3c8dd9f4950fbf88ff4ec7c47aaf854898f2689fca46a0ab13270bdceb",
"nvapi__lite__salstart_8h.html#a1f09944d9e2708540fb2f9aa31300976",
"nvapi__lite__salstart_8h.html#abe8f693445b7bc3f7ef4cecd93ef3fdd",
"structNV__D3D11__META__COMMAND__EXECUTE__GEMM__DESC.html#a04af5a2402046a183643cc6dfbabf305",
"structNV__GPU__THERMAL__SETTINGS__V1.html#a7b45151c5d9a1d4d26f601729ff849a8",
"structNV__VIEW__TARGET__INFO.html#a0c08ec5ed2dec44595b55c932c56ea6e",
"struct__NVVIOCHANNELSTATUS.html",
"struct__NV__COLOR__DATA__V5.html#ae68d23168ec4c1706de6f14fa6d36482",
"struct__NV__GPU__CLIENT__ILLUM__ZONE__CONTROL__DATA__PIECEWISE__LINEAR__RGB.html#a44881ab0e0882d45cdecde80795c114a",
"struct__NV__HDR__COLOR__DATA__V2.html",
"struct__NV__POSITION.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
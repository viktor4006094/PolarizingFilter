var structNV__MOSAIC__TOPOLOGY =
[
    [ "colCount", "structNV__MOSAIC__TOPOLOGY.html#a84e41b8ff9780588e1d9af8b1986cc4d", null ],
    [ "displayOutputId", "structNV__MOSAIC__TOPOLOGY.html#ab2da71184d2885f8077de48981b06f11", null ],
    [ "gpuLayout", "structNV__MOSAIC__TOPOLOGY.html#af166e8efcdbc769b3e3e5076301aa000", null ],
    [ "hPhysicalGPU", "structNV__MOSAIC__TOPOLOGY.html#aa8429de4bee4d7dbd3999957e7957978", null ],
    [ "overlapX", "structNV__MOSAIC__TOPOLOGY.html#ab6ada57fb4f13a495af964322a5bb5d7", null ],
    [ "overlapY", "structNV__MOSAIC__TOPOLOGY.html#a1456a613299dffa12f8c57b0ecde618d", null ],
    [ "rowCount", "structNV__MOSAIC__TOPOLOGY.html#ac44a0a243e80f00de802a6580fd87250", null ],
    [ "version", "structNV__MOSAIC__TOPOLOGY.html#a27aa4aa93ae3ffcbae680c373101dbdd", null ]
];
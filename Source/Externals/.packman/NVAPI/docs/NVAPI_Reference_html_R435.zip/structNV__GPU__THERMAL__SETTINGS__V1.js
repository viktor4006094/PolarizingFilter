var structNV__GPU__THERMAL__SETTINGS__V1 =
[
    [ "controller", "structNV__GPU__THERMAL__SETTINGS__V1.html#af5a68d398f46e6c2935fce5a91750d9d", null ],
    [ "count", "structNV__GPU__THERMAL__SETTINGS__V1.html#ab9a662799788ae98d008df57fb8cad98", null ],
    [ "currentTemp", "structNV__GPU__THERMAL__SETTINGS__V1.html#a7b5732d5bae366ef7b298332341e1516", null ],
    [ "defaultMaxTemp", "structNV__GPU__THERMAL__SETTINGS__V1.html#af8a064aebe07df8d3be6cb2ff0bc315b", null ],
    [ "defaultMinTemp", "structNV__GPU__THERMAL__SETTINGS__V1.html#a7b45151c5d9a1d4d26f601729ff849a8", null ],
    [ "sensor", "structNV__GPU__THERMAL__SETTINGS__V1.html#ab42e5cc977d975d1c5acd0ad7b6ebc4d", null ],
    [ "target", "structNV__GPU__THERMAL__SETTINGS__V1.html#adb29e4c8ae278248150836f7aa333b5f", null ],
    [ "version", "structNV__GPU__THERMAL__SETTINGS__V1.html#a8c83fc3af37b7bceabd3ebd6f8dfb4b7", null ]
];
var structNVAPI__ANSEL__FEATURE__CONFIGURATION__STRUCT =
[
    [ "featureId", "structNVAPI__ANSEL__FEATURE__CONFIGURATION__STRUCT.html#ae9d03afeeceebbee9b4cd6382767fdf6", null ],
    [ "featureState", "structNVAPI__ANSEL__FEATURE__CONFIGURATION__STRUCT.html#a6fb47f8092d5ba0d0aa59df4cc48158a", null ],
    [ "hotkey", "structNVAPI__ANSEL__FEATURE__CONFIGURATION__STRUCT.html#a988fef39c990183b2c29cbf1905c4b17", null ]
];
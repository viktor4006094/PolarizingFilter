var structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC =
[
    [ "Activation", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ad74f1235f71d8371c00f969f38961f88", null ],
    [ "Alpha1", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a41841f48ea5c3c55c0e85e8799a5f6e2", null ],
    [ "Alpha2", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a707df676b8bf4bafe0262313e189100a", null ],
    [ "DescBias", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ab7022ccda665c0aaac4a10cc04752c17", null ],
    [ "DescFilter", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#adf683437d5ca527a904678c0d4e187d9", null ],
    [ "DescIn", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a9f16d665e7d0a03f3dafd54d3e05a00b", null ],
    [ "DescOut", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ac016440904abd130f446b05e43a8faf4", null ],
    [ "Dilation", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a2341984c280d18bedb0be90cf06bbb28", null ],
    [ "DimensionCount", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#aee9c6ffdc8279337f8cc712b6f493b3e", null ],
    [ "Direction", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#aabc9dd46a4c62785e600f818801e1b47", null ],
    [ "EndPadding", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a16e38f523cfc219d085707af96eb3ce5", null ],
    [ "GroupCount", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ad2b4f5b93111af982b64f371b667486a", null ],
    [ "Mode", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a48c1ba4e03dda51ed0d2538e1221e356", null ],
    [ "Padding", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#aaec76028459b1c60c1ec24da9559e9ab", null ],
    [ "PerChannelScaling", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a760025a16089baf33dfef5b2736b2d82", null ],
    [ "Precision", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#a54c869b39c2231016b175d7e01b7759e", null ],
    [ "StartPadding", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ad2889161678d1e0d1447b8e8d7c4b1dd", null ],
    [ "Stride", "structNV__META__COMMAND__CREATE__CONVOLUTION__EX__DESC.html#ad6dec66fa615a551a53c7d625d749398", null ]
];
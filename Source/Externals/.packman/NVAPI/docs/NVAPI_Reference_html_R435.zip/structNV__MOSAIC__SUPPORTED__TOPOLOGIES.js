var structNV__MOSAIC__SUPPORTED__TOPOLOGIES =
[
    [ "topos", "structNV__MOSAIC__SUPPORTED__TOPOLOGIES.html#a07ee63bff90bf50f0767889714483122", null ],
    [ "totalCount", "structNV__MOSAIC__SUPPORTED__TOPOLOGIES.html#ad9b0f583c85e398f881509b3bebd8ea0", null ],
    [ "version", "structNV__MOSAIC__SUPPORTED__TOPOLOGIES.html#ad695bf9186d112ba38ba51e6a9243cb7", null ]
];
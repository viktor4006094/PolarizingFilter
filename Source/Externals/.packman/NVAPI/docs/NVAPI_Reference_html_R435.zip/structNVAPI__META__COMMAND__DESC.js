var structNVAPI__META__COMMAND__DESC =
[
    [ "ExecutionDirtyState", "structNVAPI__META__COMMAND__DESC.html#aa33b2e70df2dba76adfd78b0b05beb53", null ],
    [ "Id", "structNVAPI__META__COMMAND__DESC.html#adcc993b7f2015e3eebd739604850f3af", null ],
    [ "InitializationDirtyState", "structNVAPI__META__COMMAND__DESC.html#a79272aa5e71bb5034fb3a43a3cf6ac7c", null ],
    [ "Name", "structNVAPI__META__COMMAND__DESC.html#aa807626e47cdb78ba4d5ca1053bbe7e3", null ]
];
var structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC =
[
    [ "Alpha1Resource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a278bd8340f017e74f6a56ba8b4f17611", null ],
    [ "Alpha2Resource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a52ea33512663a9155495d5f6c4fc63d5", null ],
    [ "BiasResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a19c73a838b3f15447de61e9c573d0019", null ],
    [ "FilterResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a79f19381e7fb3b7ef23a8f62222351d6", null ],
    [ "InputResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a7ecb1e03cefaf31d68c24d0952f55084", null ],
    [ "OutputResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a71bff9df5dd7600227eb3e8a8fd7061d", null ],
    [ "PersistentResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a1af1ce5327273881bfed1d80dc37cb35", null ],
    [ "SkipConnectionResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#ae9a294ccee0e4c1a379e35a2b1043495", null ],
    [ "TemporaryResource", "structNV__D3D11__META__COMMAND__EXECUTE__CONVOLUTION__EX__DESC.html#a6b562242d406bf839052a786c6869a04", null ]
];
var structNV__MOSAIC__DISPLAY__SETTING__V2 =
[
    [ "bpp", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a0642ca881d900df44472da68aca61d2a", null ],
    [ "freq", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a4fa337adf97dae6cdfb4550ae5df1ca6", null ],
    [ "height", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a6b842b3efc4f71f3226173a8da65a19b", null ],
    [ "rrx1k", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a34bcd27b683a05d8cf976864656d6504", null ],
    [ "version", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a89a29ec9db10ce1135271cb42fb895a7", null ],
    [ "width", "structNV__MOSAIC__DISPLAY__SETTING__V2.html#a2fe47474534f7b3a117165d57a90ab16", null ]
];